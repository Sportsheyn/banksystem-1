package myproject.pro.commands;

import myproject.basic.commands.ICommand;
import myproject.basic.general.Bank;

import java.util.Map;

public class RepayCredit implements ICommand {


    @Override
    public String getCommandName() {
        return null;
    }

    @Override
    public void execute(Map<String, Object> params) {

    }

    @Override
    public String info() {
        return null;
    }
}
